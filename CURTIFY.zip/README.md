# CURTIFY

A small full-stack image editor that takes an uploaded target image plus a Curtis reference photo and asks an image-generation API to blend Curtis's recognizable face into the target.

## Run locally

1. Install Node.js 20+.
2. In this folder run:

```bash
npm install
```

3. Set your API key:

**macOS / Linux**
```bash
export OPENAI_API_KEY="your_key_here"
```

**Windows PowerShell**
```powershell
$env:OPENAI_API_KEY="your_key_here"
```

4. Start it:

```bash
npm start
```

5. Open `http://localhost:3000`.

## Deploy

This project needs a server-side runtime because the API key must never be placed in browser JavaScript. It can be deployed to a Node-compatible host. Add `OPENAI_API_KEY` as a secret/environment variable there.

The included `public/curtis.jpg` is the supplied Curtis reference image.
