const fileInput = document.getElementById("fileInput");
const dropzone = document.getElementById("dropzone");
const preview = document.getElementById("preview");
const fileTitle = document.getElementById("fileTitle");
const fileHint = document.getElementById("fileHint");
const prompt = document.getElementById("prompt");
const counter = document.getElementById("counter");
const button = document.getElementById("curtifyBtn");
const resultImage = document.getElementById("resultImage");
const resultEmpty = document.getElementById("resultEmpty");
const errorBox = document.getElementById("error");
const downloadBtn = document.getElementById("downloadBtn");

let selectedFile = null;

function setFile(file) {
  if (!file || !file.type.startsWith("image/")) return;
  selectedFile = file;
  preview.src = URL.createObjectURL(file);
  preview.classList.add("show");
  fileTitle.textContent = file.name;
  fileHint.textContent = `${Math.round(file.size / 1024)} KB • ready to CURTIFY`;
  button.disabled = false;
}

fileInput.addEventListener("change", e => setFile(e.target.files[0]));
["dragenter", "dragover"].forEach(type => dropzone.addEventListener(type, e => {
  e.preventDefault(); dropzone.classList.add("drag");
}));
["dragleave", "drop"].forEach(type => dropzone.addEventListener(type, e => {
  e.preventDefault(); dropzone.classList.remove("drag");
}));
dropzone.addEventListener("drop", e => setFile(e.dataTransfer.files[0]));

prompt.addEventListener("input", () => {
  counter.textContent = `${prompt.value.length} / 500`;
});

button.addEventListener("click", async () => {
  if (!selectedFile) return;

  button.classList.add("loading");
  button.disabled = true;
  errorBox.style.display = "none";
  resultImage.classList.remove("show");
  resultEmpty.classList.remove("hidden");
  downloadBtn.hidden = true;

  const form = new FormData();
  form.append("image", selectedFile);
  form.append("prompt", prompt.value);

  try {
    const response = await fetch("/api/curtify", { method: "POST", body: form });
    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "CURTIFY failed.");

    resultImage.src = data.image;
    resultImage.classList.add("show");
    resultEmpty.classList.add("hidden");
    downloadBtn.hidden = false;
    document.getElementById("resultSection").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.style.display = "block";
  } finally {
    button.classList.remove("loading");
    button.disabled = false;
  }
});

downloadBtn.addEventListener("click", () => {
  if (!resultImage.src) return;
  const a = document.createElement("a");
  a.href = resultImage.src;
  a.download = "curtified.png";
  a.click();
});


document.querySelectorAll(".quick-prompts button").forEach(btn => btn.addEventListener("click", () => { prompt.value = btn.dataset.prompt; prompt.dispatchEvent(new Event("input")); prompt.focus(); }));
