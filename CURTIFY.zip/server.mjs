import express from "express";
import multer from "multer";
import fs from "node:fs";
import path from "node:path";

const app = express();
const port = process.env.PORT || 3000;
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

app.use(express.static("public"));

app.post("/api/curtify", upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY is not configured on the server." });
    }
    if (!req.file) {
      return res.status(400).json({ error: "Please upload an image." });
    }

    const prompt = (req.body.prompt || "").trim();
    const userPrompt = [
      "CURTIFY IMAGE EDIT.",
      "The second image is the target image supplied by the user.",
      "The first image is the Curtis face reference.",
      "Create a convincing photo edit that incorporates Curtis's recognizable facial appearance into the target image.",
      "Preserve the target image's composition, setting, clothing, lighting, pose, and important objects unless the user's prompt asks for changes.",
      "Make the face integration look natural and photorealistic, with correct proportions, skin texture, lighting, and perspective.",
      prompt ? `User's additional instruction: ${prompt}` : "No additional instruction: make the most natural Curtis transformation possible.",
      "Do not add captions, watermarks, logos, or extra text."
    ].join("\n");

    const form = new FormData();
    form.append("model", "gpt-image-2");
    form.append("prompt", userPrompt);
    form.append("image[]", new Blob([fs.readFileSync(path.join("public", "curtis.jpg"))], { type: "image/jpeg" }), "curtis.jpg");
    form.append("image[]", new Blob([req.file.buffer], { type: req.file.mimetype }), req.file.originalname || "target.jpg");
    form.append("size", "auto");
    form.append("quality", "auto");
    form.append("output_format", "png");

    const response = await fetch("https://api.openai.com/v1/images/edits", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: form
    });

    const data = await response.json();
    if (!response.ok) {
      console.error(data);
      return res.status(response.status).json({
        error: data?.error?.message || "The image edit failed."
      });
    }

    const item = data?.data?.[0];
    if (!item?.b64_json) {
      return res.status(502).json({ error: "The image service returned no image." });
    }

    res.json({ image: `data:image/png;base64,${item.b64_json}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Something went wrong while CURTIFY was processing the image." });
  }
});

app.listen(port, () => {
  console.log(`CURTIFY running at http://localhost:${port}`);
});
